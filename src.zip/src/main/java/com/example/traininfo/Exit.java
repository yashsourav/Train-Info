package com.example.traininfo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Exit extends AppCompatActivity {




        {
            new AlertDialog.Builder (this)
                    .setMessage ("Are you sure you want to exit?")
                    .setCancelable (false)
                    .setPositiveButton ("Yes", new DialogInterface.OnClickListener () {
                        public void onClick(DialogInterface dialog, int id) {
                            Exit.this.finish ();

                        }
                    })
                    .setNegativeButton ("No", null)
                    .show ();
        }

    }
