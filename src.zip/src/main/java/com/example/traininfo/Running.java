package com.example.traininfo;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Running extends AppCompatActivity {
    String FileName = "myfile";
    Button btn1,btn2;
    EditText editName;
    TextView readName;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_running);
        btn1 = findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFile();
            }
        });
        btn2 = findViewById(R.id.btn2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                readFile();
            }
        });
        editName = findViewById(R.id.et1);
        readName = findViewById(R.id.Readtext);

    }
    public void readFile(){
        SharedPreferences sharedPreferences = getSharedPreferences(FileName,MODE_PRIVATE);
        String defaultValue = "DefaultName";
        String name = sharedPreferences.getString("name",defaultValue);
        readName.setText(name);
        Toast.makeText(this,"Please Wait"+name,Toast.LENGTH_SHORT).show();
    }
    public void saveFile(){
        String strName = editName.getText().toString();
        SharedPreferences sharedPreferences = getSharedPreferences(FileName,MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("name",strName);
        editor.commit();
        Toast.makeText(this,"Running Status",Toast.LENGTH_SHORT).show();

    }
}


